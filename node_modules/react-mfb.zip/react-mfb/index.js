'use strict';

module.exports = {
  Menu: require('./build/menu'),
  MainButton: require('./build/main-button'),
  ChildButton: require('./build/child-button')
};
