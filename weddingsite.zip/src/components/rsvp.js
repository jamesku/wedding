import React from 'react';

export default class Rsvp extends React.Component {
    constructor(props){
        super(props);
        
    }  
    render() {
            
    return (        
        <div>  
            
            <h1><a href="mailto:colleenkuhr@gmail.com?Subject=Wedding RSVP" target="_top">RSVP</a></h1>
        <br/>
            <h2>colleenkuhr@gmail.com</h2>
        <br/>
            <h3>(if you dont hear back from us soon, try again, or contact us through another channel)</h3>
        </div>
        );
    }
}

